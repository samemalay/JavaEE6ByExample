package dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import model.Actor;

@Stateless
public class ActorDAO {

    @PersistenceContext(unitName="dbcon")    
    EntityManager em;
    
    public ActorDAO() {}
    
    @SuppressWarnings("unchecked")
	public List<Actor> getData() {
    	//selects from entity not from table
    	Query qry = em.createQuery("select t from Actor t"); 
    	return qry.getResultList();
    }

	public boolean insert(Actor actor) {
		
		boolean ret = false;
		
		try {
			em.persist(actor);
			ret = true;
		} catch (Exception e) {
			ret = false;
			System.out.println("ActorDAO insert : Exception " + e.getMessage());
			e.printStackTrace();
		}
		
		return ret;
		
    }
	
	public boolean delete(String name) {
			
			boolean ret = false;
			
			try {
				Actor usr = em.find(Actor.class, name);
	    		em.remove(usr);
				ret = true;
			} catch (Exception e) {
				ret = false;
				System.out.println("ActorDAO delete : Exception " + e.getMessage());
				e.printStackTrace();
			}
    		
    		return ret;
		
    }
}
