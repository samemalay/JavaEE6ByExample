package sessionbeans;

import javax.ejb.Stateless;

@Stateless
public class Calc {
	
	public int getCount(String name) {
		int count = 0;
		count = name.length();
		return count;
	}

}
