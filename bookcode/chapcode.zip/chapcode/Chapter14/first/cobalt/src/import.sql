
--actor
insert into actor values('Tory Manning')
insert into actor values('Sabrina Stapledon')
insert into actor values('Albert Mercier')
insert into actor values('Alex Akulov')
insert into actor values('Rory Olsen')
insert into actor values('Gina Stanhope')
insert into actor values('Veronica Vance')
