package managedbeans;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

import model.Actor;
import dao.ActorDAO;

@ManagedBean(name="actor")
@RequestScoped
public class ActorBean {

	@EJB
	private ActorDAO actordao;
	
	String name;
	private String rating;
	private List<Actor> actorLst;
	
	ActorComparator comp  = new ActorComparator();
	
	@SuppressWarnings("unused")
	@PostConstruct
	private void postCon() {
		actorLst = actordao.getData();
		Collections.sort(actorLst,comp);
	}
	
	public List<Actor> getList() {
		return actorLst;
	}
				
	public String add() {
		
		Actor actor = new Actor(name);
		if (!actorLst.contains(actor)) 
			if (actordao.insert(actor)) {
				actorLst.add(actor);
				Collections.sort(actorLst,comp);
			}
		setName(null);
		return null;
	}
	
	public String delete(Actor actor) { 

		if (actordao.delete(actor.getName())) {
			actorLst.remove(actor);
			Collections.sort(actorLst,comp);
		}
		return "actor";
	}
	
	public String check(String name) { 
		return null;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public class ActorComparator implements Comparator<Actor> {

	    @Override
	    public int compare(Actor u1, Actor u2) {
	          return u1.getName().compareTo(u2.getName());
	    }           
	}

}
