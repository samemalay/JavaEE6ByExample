package util;

import java.util.ArrayList;
import java.util.List;

import model.Actor;

public class MiscList {

	public static List<Actor> actorList = new ArrayList<Actor>();
	
	public static void populateActors() {
		
	}
	
	public static List<Program> progList = new ArrayList<Program>();
	
	public static void populateProgs() {
		
		Program prog;
		progList.clear();
		
		prog = new Program("Huntingdale", "Serial", "06/06/2013");
		progList.add(prog);
		prog = new Program("Kitchen King", "Reality show", "03/07/2013");
		progList.add(prog);
		prog = new Program("Snowman", "Movie", "05/07/2013");
		progList.add(prog);

	}

}
