package model;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "program")
public class Program 
{
	
	@Id
	@Column(name = "name")
	private String name;

	@Column(name = "dt")
	@Temporal(TemporalType.DATE)
	private Date dt;
	
	@Column(name = "slot")
	private int slot;
	
	@Column(name = "programtype")
	private String ptype;
	
	@Column(name = "classification")
	private String classi;
	
	@Column(name = "in3d")
	private boolean in3d;
	
	@Column(name = "description")
	private String desc;
	
	@Column(name = "actor")
	private String actor;

	public Program() {}

	public Program(String name, Date dt, int slot, String ptype, String classi,
			boolean in3d, String desc, String actor) {
		this.name = name;
		this.dt = dt;
		this.slot = slot;
		this.ptype = ptype;
		this.classi = classi;
		this.in3d = in3d;
		this.desc = desc;
		this.setActor(actor);
	}

	public void afterViewParam() {}

	public String getName () {
        return name;
    }

    public void setName (final String name) {
        this.name = name;
    }

	public Date getDt() {
		return dt;
	}

	public void setDt(Date dt) {
		this.dt = dt;
	}

	public int getSlot() {
		return slot;
	}

	public void setSlot(int slot) {
		this.slot = slot;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	public String getPtype() {
		return ptype;
	}

	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	
	public boolean isIn3d() {
		return in3d;
	}

	public void setIn3d(boolean in3d) {
		this.in3d = in3d;
	}
	
	public String getClassi() {
		return classi;
	}

	public void setClassi(String classi) {
		this.classi = classi;
	}

	public String getSlotDisp() {
		
		String slotDisp;
		
		switch (slot) {
		case 1: 
			slotDisp = "6.30 - 7.30 PM";
			break;
		case 2: 
			slotDisp = "7.30 - 8.30 PM";
			break;	
		case 3: 
			slotDisp = "8.30 - 9.30 PM";
			break;
		case 4: 
			slotDisp = "9.30 - 10.30 PM";
			break;
		default:
			slotDisp = "6.30 - 7.30 PM";
		}
		return slotDisp;
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}
	
}
