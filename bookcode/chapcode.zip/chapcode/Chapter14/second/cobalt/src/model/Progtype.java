package model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "progtype")
public class Progtype {
	
	@Id
	@Column(name = "name")
	private String name;

	public Progtype() {}
	
	public Progtype(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
    public boolean equals(Object obj) {
		
		 if(obj != null && obj instanceof Progtype) {
			 Progtype usr2 = (Progtype) obj;
			 return this.name.equals(usr2.name);
		 }
		 
		 return false;
        
    }


}
