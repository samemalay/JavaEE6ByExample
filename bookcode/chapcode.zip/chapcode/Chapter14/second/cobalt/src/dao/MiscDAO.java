package dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class MiscDAO {

    @PersistenceContext(unitName="dbcon")    
    EntityManager em;
    
    public MiscDAO() {}
    
    @SuppressWarnings("unchecked")
	public List<String> getProgTypes() {
    	Query qry = em.createQuery("select t.name from Progtype t");
    	return qry.getResultList();
    }

}
