package dao;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import model.Program;

@Stateless
public class ProgramDAO {

    @PersistenceContext(unitName="dbcon")    
    EntityManager em;
    
    public ProgramDAO() {
    }
    
    @SuppressWarnings("unchecked")
	public List<Program> getData() {
    	Query qry = em.createQuery("select t from Program t"); 
    	return qry.getResultList();
    }

	public boolean addMod(Program prg) {
		
		boolean ret = false;
		
		try {
			Program dbprg = em.find(Program.class, prg.getName());
			if (dbprg != null) {
				dbprg.setClassi(prg.getClassi());
				dbprg.setDesc(prg.getDesc());
				dbprg.setIn3d(prg.isIn3d());
				dbprg.setPtype(prg.getPtype());
				dbprg.setSlot(prg.getSlot());
			}
			else {
				em.persist(prg);
			}
			ret = true;
		} catch (RuntimeException e) {
			ret = false;
			System.out.println("ProgramDAO addMod : RuntimeException " + e.getMessage());
			e.printStackTrace();
		} catch (Exception e) {
			ret = false;
			System.out.println("ProgramDAO addMod : Exception " + e.getMessage());
			e.printStackTrace();
		}

		return ret;
		
    	}
	
		public boolean delete(String name) {
			
			boolean ret = false;
			
			try {
				Program prg = em.find(Program.class, name);
	    		em.remove(prg);
				ret = true;
			} catch (Exception e) {
				ret = false;
				System.out.println("ProgramDAO delete : Exception " + e.getMessage());
				e.printStackTrace();
			}
    		
    		return ret;
		
    	}
}
