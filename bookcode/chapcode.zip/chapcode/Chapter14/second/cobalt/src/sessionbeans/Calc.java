package sessionbeans;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import model.Program;

@Stateless
public class Calc {

	@EJB
	private ProgList plist;
	
	public int getCount(String name) {
		
		int count = 0;
		
		for (Program prg : plist.getPlist()) {
			if (prg.getActor().equals(name))
				count++;
		}
		
		return count;
	}

}
