package sessionbeans;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.TimeZone;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.ejb.Stateless;

import model.Program;

import dao.ProgramDAO;

@Stateless
public class ProgList {
	
	@EJB
	private ProgramDAO prdao;
	
	private static HashMap<String, Program> pMap = new HashMap<String, Program>();
	private boolean noprog;

	ProgList() {
		TimeZone.setDefault( TimeZone.getTimeZone("GMT") );
	}
	
	public void populate() {
		List<Program> pl = prdao.getData();
		if (pl.size() > 0)
			noprog = false;
		else
			noprog = true;
		for (Program prg : pl) {
			pMap.put(prg.getName(), prg);
		}		
	}
	
	@SuppressWarnings("unused")
	@PostConstruct
	private void postCon() {
		populate();
	}

	public List<Program> getPlist() {
		return new ArrayList<Program>(pMap.values());
	}
	
	public static Program getProgram(String name) {
		return pMap.get(name);
	}
	
	public static Program setProgram(String name, Program prg) {
		return pMap.put(name,prg);
	}

	public boolean isNoprog() {
		return noprog;
	}

	public void setNoprog(boolean noprog) {
		this.noprog = noprog;
	}
	
	public String add(Program prg) {

		if (prdao.addMod(prg)) {
			pMap.put(prg.getName(), prg);
		}
		
		return "view";
	}
	
	public String delete(String name) {
		
		if (prdao.delete(name)) {
			pMap.remove(name);
		}
		
		return "view";
	}

}
