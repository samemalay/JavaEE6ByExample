package sessionbeans;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.ejb.Singleton;
import dao.MiscDAO;

@Singleton
public class ProgTypeList {
	
	@EJB
	private MiscDAO miscDAO;
	
	public Map<String,String> getProgTypes() {
		
		Map<String,String> map = new HashMap<String,String>();
		List<String> typeList = miscDAO.getProgTypes();
		
		for (String progtype : typeList) {
			map.put(progtype, progtype);
		}
		
		return map;
	}
	
}
