
--actor
insert into actor values('Tory Manning')
insert into actor values('Sabrina Stapledon')
insert into actor values('Albert Mercier')
insert into actor values('Alex Akulov')
insert into actor values('Rory Olsen')
insert into actor values('Gina Stanhope')
insert into actor values('Veronica Vance')

--program
insert into program(name,dt,slot,programtype,classification,in3d,description,actor) values('NCIS','2013-02-01',3,'Serial','M',1,'Exciting new epsiode of NCIS. A terrorist organization wages war. Should the team be able to stand upto it?','Tory Manning')
insert into program(name,dt,slot,programtype,classification,in3d,description,actor) values('Castle','2013-02-03',3,'Serial','M',0,'Castle is still in a bank, when robbers seize it. They are not after money, so what are they looking for?','Tory Manning')
insert into program(name,dt,slot,programtype,classification,in3d,description,actor) values('Elementary','2013-02-03',4,'Serial','M',1,'Has Holmes finally met his intellectual match?','Tory Manning')
insert into program(name,dt,slot,programtype,classification,in3d,description,actor) values('Bones','2013-02-04',3,'Serial','M',0,'The team unearthed body of a person who appears to be missing 3 years ago.','Tory Manning')
insert into program(name,dt,slot,programtype,classification,in3d,description,actor) values('Masterchef','2013-02-04',2,'Reality show','G',1,'Two teams come head to head with their culinary skills in the outback.','Tory Manning')

--progType
insert into progtype values('Movie')
insert into progtype values('Serial')
insert into progtype values('Reality show')
insert into progtype values('Current affairs')