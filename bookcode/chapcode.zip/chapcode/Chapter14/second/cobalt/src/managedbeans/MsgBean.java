package managedbeans;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import sessionbeans.Pageview;

@ManagedBean(name="show")
@SessionScoped
public class MsgBean {
	
	//important to be SessioScoped for 
	//using Stateful bean
	
	@EJB 
	private Pageview page;

	private static String msg;

	public String getMsg() {
		return msg;
	}

	public static void setMsg(String msg) {
		MsgBean.msg = msg;
	}

	public void incrCount() {
		page.setCount();
	}

	public String getViewed() {
		return "This page has been viewed : " + page.getCount() + 
				" time(s) [current session]";
	}


}
