package managedbeans;

import java.util.Date; 
import java.util.HashMap;
import java.util.Map;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import dao.ActorDAO;
import sessionbeans.ProgList;
import sessionbeans.ProgTypeList;
import model.Program;
import model.Actor;

@ManagedBean(name="prog")
@SessionScoped
public class ProgramBean {
	
	@EJB
	private ProgList plist;
	
	@EJB
	private ProgTypeList types;
	
	@EJB
	private ActorDAO actorDAO;

	private String name;
	private Date dt;
	private int slot;
	private String ptype;
	private boolean in3d;
	private String classi;
	private String desc;
	private String actor;
	
	public ProgramBean() {
		classi = "M";
	}

	private Program getPrg() {
		java.sql.Date sqlDt = new java.sql.Date(dt.getTime());
		Program prg = new Program(name, sqlDt, slot, ptype, classi, in3d, desc, actor);
		return prg;
	}
	
	public String add() {
		plist.add(getPrg());
		return "view";
	}
	
	public String delete() {
		plist.delete(name);
		return "view";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getDt() {
		return dt;
	}

	public void setDt(Date dt) {
		this.dt = dt;
	}

	public int getSlot() {
		return slot;
	}

	public void setSlot(int slot) {
		this.slot = slot;
	}

	public String getPtype() {
		return ptype;
	}

	public void setPtype(String ptype) {
		this.ptype = ptype;
	}

	public boolean isIn3d() {
		return in3d;
	}

	public void setIn3d(boolean in3d) {
		this.in3d = in3d;
	}

	public String getClassi() {
		return classi;
	}

	public void setClassi(String classi) {
		this.classi = classi;
	}

	public String getDesc() {
		return desc;
	}

	public void setDesc(String desc) {
		this.desc = desc;
	}

	@SuppressWarnings("unused")
	@PostConstruct
	private void postCon() {}
	
	public Map<String,Integer> getSlotValue() {
		
		Map<String,Integer> slotMap = new HashMap<String,Integer>();
		
		slotMap.put("6.30 - 7.30 PM",1);
		slotMap.put("7.30 - 8.30 PM",2);
		slotMap.put("8.30 - 9.30 PM",3);
		slotMap.put("9.30 - 10.30 PM",4);
		
		return slotMap;
	}
	
	public Map<String,String> getActorMap() {
		
		Map<String,String> actorMap = new HashMap<String,String>();
		List<Actor> actorList = actorDAO.getData();
		
		for (Actor actor : actorList) {
			actorMap.put(actor.getName(), actor.getName());
		}
		
		return actorMap;
	}
	
	public Map<String,String> getTypes() {
		return types.getProgTypes();
	}

	public String getActor() {
		return actor;
	}

	public void setActor(String actor) {
		this.actor = actor;
	}
	
	public void afterViewParam() {}

}
