package managedbeans;

import java.util.List;
import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import sessionbeans.ProgList;

import model.Program;

@ManagedBean(name="chart")
@SessionScoped
public class ProgListBean {
	
	@EJB
	private ProgList plist;
	
	public ProgListBean() {}
	
	public List<Program> getList() {
		return plist.getPlist();
	}

}
