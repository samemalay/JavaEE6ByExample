package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.jms.*;
import javax.naming.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/produce")
public class Producer extends HttpServlet {
 
	private static final long serialVersionUID = 1L;
	
	public String getCurrentTime() {
	    SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    Date now = new Date();
	    String strDate = sdfDate.format(now);
	    return strDate;
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	     String destinationName = "queue/test";
	     PrintWriter out = response.getWriter();
	     Context ic = null;
	     ConnectionFactory cf = null;
	     Connection connection =  null;
	
	     try {         
	       ic = new InitialContext();
	
	       cf = (ConnectionFactory)ic.lookup("/ConnectionFactory");
	       Queue queue = (Queue)ic.lookup(destinationName);
	
	       connection = cf.createConnection();
	       Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
	       MessageProducer publisher = session.createProducer(queue);
	 
	       connection.start();
	
	       TextMessage message = session.createTextMessage("Happy Messaging @ " + getCurrentTime());
	       publisher.send(message);
	
	       out.println("Message sent to the JMS Provider");
	
	    } catch (Exception exc) { exc.printStackTrace(); }
	    finally {         
	      if (connection != null)   {
	        try { connection.close(); 
	        } catch (JMSException e) { e.printStackTrace(); }
	      } 
	    }
	}

   protected void doPost(HttpServletRequest request, HttpServletResponse response) 
		   throws ServletException, IOException {
     doGet(request, response);
   }

}
