package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MiscList {
	
	public static Map<String,String> actorMap = new HashMap<String,String>();
	
	public static Map<String,String> typesMap = new HashMap<String,String>();
	
	public static void init() {
		//populate actor data
		actorMap.put("Tory Manning", "Tory Manning");
		actorMap.put("Ron Chinoi", "Ron Chinoi");
		actorMap.put("Alisha Gartner", "Alisha Gartner");
		
		//populate program type data
		typesMap.put("Serial", "Serial");
		typesMap.put("Reality Show", "Reality Show");
	}
	
	public static List<Actor> actorList = new ArrayList<Actor>();
	
	public static void populateActors() {
		
		Actor actor;
		
		actorList.clear();
		
		actor = new Actor("Tory Manning", "lead actor");
		actorList.add(actor);
		
		actor = new Actor("Ron Chinoi", "supporting");
		actorList.add(actor);
		
		actor = new Actor("Alisha Gartner", "heroine");
		actorList.add(actor);

	}
		
	

}
