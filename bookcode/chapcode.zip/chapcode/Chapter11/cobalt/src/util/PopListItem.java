package util;

public class PopListItem {
	
	private String label;
	private int val;
	
	public String getLabel() {
		return label;
	}
	
	public PopListItem(String label, int val) {
		this.label = label;
		this.val = val;
	}

	public void setLabel(String label) {
		this.label = label;
	}
	
	public int getVal() {
		return val;
	}
	
	public void setVal(int val) {
		this.val = val;
	}
	
	

}
