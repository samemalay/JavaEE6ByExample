package managedbeans;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import util.Actor;
import util.MiscList;

@ManagedBean(name="actor")
@SessionScoped
public class ManageActor {

	String name;
	String role;
	private List<Actor> actorLst;
	
	ActorComparator comp  = new ActorComparator();
	
	public ManageActor() {
		MiscList.populateActors();
		actorLst = MiscList.actorList;
	}

	public List<Actor> getList() {
		return actorLst;
	}
				
	public String add() {
		
		Actor actor; 
		boolean contains = false;
		
		for (Actor cur : actorLst) {
			if (cur.getName().equals(name)) {
				contains = true;
				break;
			}
		}
		
		if (!contains) {
			actor = new Actor(name, role);
			actorLst.add(actor);
			Collections.sort(actorLst,comp);
		}
		
		this.name = null;
		this.role = null;

		return null;
	}
	
	public String delete(Actor actor) { 
		actorLst.remove(actor);
		Collections.sort(actorLst,comp);
			
		return "actor";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public class ActorComparator implements Comparator<Actor> {

	    @Override
	    public int compare(Actor u1, Actor u2) {
	          return u1.getName().compareTo(u2.getName());
	    }           
	}

}
