package code;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name="prepared")
@RequestScoped
public class BakedBean {
	
	private String forShow = "Just Checking";

	public String getForShow() {
		return forShow;
	}

	public void setForShow(String forShow) {
		this.forShow = forShow;
	}

}
