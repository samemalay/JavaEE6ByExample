package converter;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("goodname")
public class NameValidate implements Validator {

	@Override
	public void validate(
				FacesContext context, 
				UIComponent component, 
				Object value) throws ValidatorException {
		
		String givenName = value.toString();
		
		if (givenName.equals("Mad") ||
				givenName.equals("Bad") ||
				givenName.equals("Dangerous")) {
		
			FacesMessage msg = new FacesMessage("Error", "Name validation failed.");
			msg.setSeverity(FacesMessage.SEVERITY_ERROR);
			throw new ValidatorException(msg);
		}
		
	}

}
