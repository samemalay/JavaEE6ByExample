package managedbeans;

import java.util.Date;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

import util.MiscList;
import util.Program;

@ManagedBean(name="prog")
@SessionScoped
public class ProgramBean {
	
	private String name;
	private String ptype;
	private Date dt;
	private int size;
	
	public ProgramBean() {
		MiscList.populateProgs();
	}
	
	public List<Program> getList() {
		
		return MiscList.progList;
	}
	
	public void afterViewParam() {
		this.size = name.length();
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPtype() {
		return ptype;
	}

	public void setPtype(String ptype) {
		this.ptype = ptype;
	}
	
	
	public Date getDt() {
		return dt;
	}

	public void setDt(Date dt) {
		this.dt = dt;
	}

	public int getSize() {
		return size;
	}

	public void setSize(int size) {
		this.size = size;
	}

}
