package util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MiscList {
	
	public static Map<String,String> actorMap = new HashMap<String,String>();
	
	public static void init() {
		//populate actor data
		actorMap.put("Tory Manning", "Tory Manning");
		actorMap.put("Ron Chinoi", "Ron Chinoi");
		actorMap.put("Alisha Gartner", "Alisha Gartner");
	}
	
	public static List<Actor> actorList = new ArrayList<Actor>();
	
	public static void populateActors() {
		
		Actor actor;
		
		actorList.clear();
		
		actor = new Actor("Tory Manning", "lead actor");
		actorList.add(actor);
		
		actor = new Actor("Ron Chinoi", "supporting");
		actorList.add(actor);
		
		actor = new Actor("Alisha Gartner", "heroine");
		actorList.add(actor);

	}
	
	public static List<Program> progList = new ArrayList<Program>();
	
	public static void populateProgs() {
		
		Program prog;
		progList.clear();
		
		prog = new Program("Huntingdale", "Serial", "06/06/2013");
		progList.add(prog);
		prog = new Program("Kitchen King", "Reality show", "03/07/2013");
		progList.add(prog);
		prog = new Program("Snowman", "Movie", "05/07/2013");
		progList.add(prog);

	}

}
