package util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Program {
	
	String name;
	String progType;
	Date dt;
	
	public Program(String name, String progType, String dtStr) {
		
		this.name = name;
		this.progType = progType;
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		Date dt = null;
		try {
			dt = sdf.parse(dtStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		this.dt = new java.sql.Date(dt.getTime());
	}
	
	public Date getDt() {
		return dt;
	}

	public void setDt(Date dt) {
		this.dt = dt;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	
	public String getProgType() {
		return progType;
	}

	public void setProgType(String progType) {
		this.progType = progType;
	}



}
