package sessionbeans;

import java.io.Serializable;
import javax.ejb.Stateful;

@Stateful
public class Pageview implements Serializable {

	private static final long serialVersionUID = 1L;
	private int count = 0;

	public int getCount() {
		return count;
	}

	public void setCount() {
		this.count++;
	}

}
