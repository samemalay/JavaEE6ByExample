package code;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
public class TestDAO {
	
    @PersistenceContext(unitName="dbcon")    
    EntityManager em;
    
    public TestDAO() {
    	
    }
    
    public TestCon getData() {
    	Query qry = em.createQuery("select t from TestCon t");
    	TestCon tcon = (TestCon) qry.getSingleResult();
    	String rslt = tcon.getB();
		if (rslt == null || rslt.equals(""))
			rslt = "Could not get result";
		System.out.println("Result is " + rslt);
        return tcon;
    }

}
