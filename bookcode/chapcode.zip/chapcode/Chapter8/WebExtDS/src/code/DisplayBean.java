package code;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.bean.*; 

@ManagedBean(name="MyBean")
@RequestScoped
public class DisplayBean implements java.io.Serializable { 
	
	@EJB
	private TestDAO dao;
	
	private TestCon tcon;

	private static final long serialVersionUID = 1L;
	
	private static String message = "Awaiting ...";
	
	@PostConstruct
	private void postCon() {
		tcon = dao.getData();
	}
	
	public String getMessage() {
		String rslt = tcon.getB();
		if (rslt == null || rslt.equals(""))
			rslt = "Could not get result";
		message = "Result is " + rslt;
		return message;
	}
	
	public static void setMessage(String msg) {
		message = msg;
	}
	
}