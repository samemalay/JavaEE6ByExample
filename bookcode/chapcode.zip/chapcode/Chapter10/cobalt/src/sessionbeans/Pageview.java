package sessionbeans;

import javax.ejb.Stateful;

@Stateful
public class Pageview {

	private int count = 0;

	public int getCount() {
		return count;
	}

	public void setCount() {
		this.count++;
	}

}
