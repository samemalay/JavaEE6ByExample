package messagebean;

import javax.ejb.ActivationConfigProperty;
import javax.ejb.MessageDriven;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.TextMessage;

import managedbeans.MsgBean;

@MessageDriven(name = "MessageMDB", activationConfig = {
 @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "javax.jms.Queue"),
 @ActivationConfigProperty(propertyName = "destination", propertyValue = "queue/test"),
 @ActivationConfigProperty(propertyName = "acknowledgeMode", propertyValue = "Auto-acknowledge") })

public class ConsumerMDB implements MessageListener {
	
   public void onMessage(Message message) {

     TextMessage tm = (TextMessage) message;
     String msg = "";
       try {
    	 msg = tm.getText();
    	 setMsg(msg);
       } catch (JMSException e) { e.printStackTrace(); }

   }
   
   public void setMsg(String msgtxt) {

	   MsgBean.setMsg(msgtxt);
   
   }

}