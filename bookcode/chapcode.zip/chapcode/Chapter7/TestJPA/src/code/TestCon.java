package code;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "testcon", schema = "test")
public class TestCon {


		@Id
		@Column(name = "a")
		private int a;

	    @Column(name = "b", length = 20)
	    private String b;
	    
	    public String getB() {
	    	return b;
	    }

}
