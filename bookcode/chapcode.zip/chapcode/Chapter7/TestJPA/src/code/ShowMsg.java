package code;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;

import javax.swing.JFrame;
import javax.swing.JPanel;

public class ShowMsg extends JPanel {

	private String text = "Text";
   
   ShowMsg (String text) {
	   this.text = text;
	   JFrame f = new JFrame();
	   f.getContentPane().add(this);
	   f.setSize(400, 200);
	   f.setVisible(true);
   }
	
   public void paint(Graphics g) {
      Graphics2D g2 = (Graphics2D)g;
      g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
      Font font = new Font("Serif", Font.PLAIN, 36);
      g2.setFont(font);
      g2.drawString(text, 80, 80);
   }

}

