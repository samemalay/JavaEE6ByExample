package code;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Test {
	
	private static String PERSISTENCE_UNIT_NAME = "TestJPA";
	private static EntityManagerFactory emFactory;

	public static void main(String[] args) {
		
		String rslt = "";
		
		try {
			emFactory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
			EntityManager em = emFactory.createEntityManager();
			Query qry = em.createQuery("select t from TestCon t");
			TestCon tcon = (TestCon) qry.getSingleResult();
			rslt = tcon.getB();
			if (rslt == null || rslt.equals(""))
				rslt = "Could not get result";
			new ShowMsg(rslt);
		} catch (Exception ex) {
			new ShowMsg("Exception occured");
		}

	}

}
