create table tvprog (
progname        varchar2(30)    not null,
progdate        date            not null,
slot            varchar2(30)    not null,
progtype        varchar2(20)    not null,
classification  varchar2(10)    not null,
description     varchar2(500)   not null,
constraint tvprog_pk primary key (progname, progdate)
);

create table testcon (
  a	   numeric(2,0)    not null,
  b    varchar2(20)    not null,
  constraint testcon_pk primary key (a)
);

insert into testcon values(1,'Connection OK');
commit;
