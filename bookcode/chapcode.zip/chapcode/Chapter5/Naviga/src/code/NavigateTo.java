package code;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;

@ManagedBean(name="navigateTo")
@RequestScoped
public class NavigateTo {

	public String target() {
		return "result";
	}

	public String withRedirection() {
		return "result?faces-redirect=true";
	}

}
